-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: laravel
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'Admin','admin@keyndex.in',NULL,NULL,NULL,'$2y$12$izeOBGy3FwOs16VRtRxXu.be/7MpD8lKh8BKO0KiYuvorMTqCSwc2',1,'2025-01-08 01:09:28','2025-01-08 01:09:28');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_size` double NOT NULL DEFAULT 0,
  `checksum` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `backup_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backups_created_by_foreign` (`created_by`),
  CONSTRAINT `backups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
INSERT INTO `backups` VALUES (1,'backup','E:\\base-template\\keyndex-server\\storage\\backups/laravel_2025-01-08_06-41-06.zip',6946,'3cd7c44622cf9d1252e159c09c753a1e',1,'2025-01-08 01:11:07','2025-01-08 01:11:07','2025-01-08 01:11:07'),(2,'backup','E:\\base-template\\keyndex-server\\storage\\backups/laravel_2025-01-08_07-30-37.zip',7044,'65669a279af0f32eb6ffeb85c358c8a7',1,'2025-01-08 02:00:38','2025-01-08 02:00:38','2025-01-08 02:00:38'),(3,'backup','E:\\base-template\\keyndex-server\\storage\\backups/laravel_2025-01-08_07-30-46.zip',7109,'93e85647f9758707eaa35b3e109aa406',1,'2025-01-08 02:00:47','2025-01-08 02:00:47','2025-01-08 02:00:47');
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keyndex_templates`
--

DROP TABLE IF EXISTS `keyndex_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keyndex_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `structure` text NOT NULL,
  `default_content` text DEFAULT NULL,
  `content_type` enum('json','html','markdown') NOT NULL DEFAULT 'json',
  `version` decimal(8,2) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyndex_templates_title_unique` (`title`),
  UNIQUE KEY `keyndex_templates_identifier_unique` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keyndex_templates`
--

LOCK TABLES `keyndex_templates` WRITE;
/*!40000 ALTER TABLE `keyndex_templates` DISABLE KEYS */;
INSERT INTO `keyndex_templates` VALUES (1,'Section Hero','hero','{\"title\":\"Welcome to my webpage\",\"subTitle\":\"Sample description home automation in this information inversion into meaning.\"}',NULL,'json',1.00,1,'2025-01-08 01:09:29','2025-01-08 01:09:29');
/*!40000 ALTER TABLE `keyndex_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_activities`
--

DROP TABLE IF EXISTS `login_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL DEFAULT '0.0.0.0',
  `user_agent` varchar(255) DEFAULT NULL,
  `logged_in_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `logged_out_at` timestamp NULL DEFAULT NULL,
  `operating_system` enum('linux','windows','mac','android','ios','unknown') DEFAULT NULL,
  `login_type` enum('email','google') DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_activities_user_id_foreign` (`user_id`),
  CONSTRAINT `login_activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_activities`
--

LOCK TABLES `login_activities` WRITE;
/*!40000 ALTER TABLE `login_activities` DISABLE KEYS */;
INSERT INTO `login_activities` VALUES (1,'0.0.0.0',NULL,'2025-01-08 06:39:29',NULL,'linux','email',0,1,'2025-01-08 01:09:29','2025-01-08 01:09:29');
/*!40000 ALTER TABLE `login_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2024_12_03_084804_create_personal_access_tokens_table',1),(5,'2024_12_03_140232_create_admins_table',1),(6,'2024_12_03_144517_create_subscription_plans_table',1),(7,'2024_12_03_144640_create_subscription_histories_table',1),(8,'2024_12_03_144736_create_notifications_table',1),(9,'2024_12_03_144822_create_policies_table',1),(10,'2024_12_16_080609_create_login_activities',1),(11,'2024_12_26_062026_create_verification_codes',1),(12,'2025_01_01_073700_create_pages',1),(13,'2025_01_01_075530_create_page_contents',1),(14,'2025_01_01_082149_create_keyndex_templates',1),(15,'2025_01_03_073019_create_settings',1),(16,'2025_01_07_140054_create_backups_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(100) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('global','group','single','task','project') NOT NULL DEFAULT 'global',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `target_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,NULL,'Welcome to Keyndex','Easy management of your projects and tasks. Get started with Keyndex today!','global',1,NULL,'2025-01-08 01:09:29','2025-01-08 01:09:29');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_contents`
--

DROP TABLE IF EXISTS `page_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_contents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `content_type` enum('json','html','markdown') NOT NULL DEFAULT 'json',
  `version` decimal(8,2) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_contents`
--

LOCK TABLES `page_contents` WRITE;
/*!40000 ALTER TABLE `page_contents` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_desc` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `policies`
--

DROP TABLE IF EXISTS `policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `policies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `type` enum('privacy','terms','refund','cancellation') NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `policies`
--

LOCK TABLES `policies` WRITE;
/*!40000 ALTER TABLE `policies` DISABLE KEYS */;
INSERT INTO `policies` VALUES (1,'privacy','Et ut culpa voluptas et. Cum voluptatem accusantium et corrupti sed esse. Quos est quia provident eveniet soluta eius ut quo. Molestiae dolore molestias modi eligendi iure incidunt.\n\nMolestiae placeat sit provident optio rerum est. Accusantium iure repellat odit accusantium.\n\nFacere provident ut non corporis. Ipsum sapiente eligendi ullam aut aliquam iste. Iusto ullam corrupti facilis nesciunt vitae nemo est.\n\nOfficia ad magnam eos. Quia sequi officiis magni corrupti corporis error rerum. Adipisci tempore ex praesentium cumque.\n\nQui sit rerum aut. Voluptas autem eius soluta quia fugit nihil. Mollitia itaque sit dolores eos distinctio.\n\nPlaceat qui recusandae excepturi aperiam non. Quo fugit iusto a ad sed. Explicabo autem enim hic quia aspernatur nihil est.\n\nCupiditate voluptatem fugit et. Omnis excepturi est repellendus sequi. In dolor qui enim quasi dignissimos magni. Officiis perspiciatis sint nulla itaque.\n\nQuam reiciendis voluptate et dignissimos consequatur commodi impedit. Qui reprehenderit molestiae ea rerum incidunt minima omnis. Velit esse voluptatum quae quia.\n\nNihil id consequatur quia quo in rem iure. Voluptatem labore sit animi hic iste rem dolores. Culpa placeat pariatur molestias unde. Sunt sit et accusamus.\n\nUt numquam laudantium mollitia id. Fuga deleniti et est reiciendis recusandae autem. Ullam nam voluptatem magnam corporis cumque. Ut hic ut qui deleniti.','privacy',1,'2025-01-08 01:09:29','2025-01-08 01:09:29'),(2,'terms','Non eos tempore et hic incidunt aut aut. Mollitia ut cupiditate iusto veniam aperiam quos. Et dolorum natus est enim. Quis omnis rerum et aut ex nesciunt non quod.\n\nEveniet quia sint eaque in vero veritatis. Voluptatem amet excepturi et sint dolorum eaque. Suscipit itaque voluptate nostrum mollitia. Harum voluptas tenetur sit voluptas error iure qui est.\n\nEt quis veritatis aut nemo. Nobis neque nesciunt consequatur cum.\n\nAliquam tenetur cumque et. Quae deleniti omnis error voluptatem aut. Labore nostrum et nobis quidem voluptas ratione dignissimos sed.\n\nNam aut nihil accusantium voluptas. Maiores molestiae incidunt dicta esse quaerat ut ea id.\n\nVoluptate non facere architecto dolorem eos velit. Incidunt tenetur deserunt et dolores quas numquam animi est. Laboriosam veniam ex consectetur quis quia perferendis excepturi. Sed quidem aliquid sed quas veritatis incidunt.\n\nAliquid eos debitis veritatis aut sit soluta blanditiis. Voluptas praesentium et aliquid vitae. Aut id laboriosam enim tenetur.\n\nIpsa laudantium aut reprehenderit enim nisi. Porro et ut ipsum ipsa dolor provident debitis. Blanditiis vel rem similique fugiat ipsum illo omnis.\n\nCorporis et dicta quia voluptatem incidunt dolores. Molestiae laborum ab harum voluptatem alias voluptatem odit. Repellendus facilis consequatur ea et. Impedit tenetur quibusdam vitae voluptatibus.\n\nQuod non provident nesciunt perspiciatis. Qui in doloremque id voluptatem quia necessitatibus voluptatibus. Aut qui maxime quam dolorem dolorum totam porro. Voluptatem velit est at molestias laboriosam nihil. Eum sed vero voluptatem adipisci dolores.','terms',1,'2025-01-08 01:09:29','2025-01-08 01:09:29'),(3,'refund','Libero pariatur quos repudiandae ut doloremque numquam aut. Dolorum eaque sit vel ut. Illo at vitae repellat consequatur voluptatem natus ullam.\n\nHarum deleniti dolorem quo beatae atque eveniet alias. Nam itaque vero magni quas quod et. Explicabo numquam non neque sit nobis.\n\nVoluptas est temporibus ea excepturi neque pariatur numquam. Quis rerum pariatur perspiciatis suscipit quisquam. Ut voluptatem quis beatae commodi. Alias laboriosam hic ut delectus aliquam.\n\nSimilique cupiditate ullam sapiente sequi et. Esse voluptatem sunt et possimus sit. Minus praesentium dicta nostrum ullam sint aut sequi sed. Sunt amet rerum cupiditate labore ducimus.\n\nDoloremque autem nobis aspernatur sit molestiae. Consequatur est magni eos quia natus ab. Provident sapiente sit amet illo reprehenderit in.\n\nOfficia alias labore veniam. Exercitationem quo molestiae et ipsa dolore. Expedita vero non est tempore earum quis odit.\n\nAut sunt cumque aut ut officia vel. Blanditiis et sed aut voluptates cum et. Hic consequuntur et error. Natus non dolores quaerat rerum.\n\nLaborum necessitatibus quia delectus aut voluptate in quam molestiae. Necessitatibus impedit excepturi eum quis. Laborum optio quod qui quo sequi iste iure porro. Est dolores natus ut aperiam et possimus et est.\n\nInventore aliquam vitae quam amet quam ea id. Ut ex commodi fugit modi qui. Nobis sint hic officia est dolor.\n\nAtque velit est nisi voluptate ad id excepturi doloremque. Deleniti ullam sapiente unde voluptas. Dolore et enim voluptas corporis vero nisi iste. Sed reprehenderit reiciendis velit voluptate facilis eos.','refund',1,'2025-01-08 01:09:29','2025-01-08 01:09:29'),(4,'cancellation','Cupiditate quos omnis quos dolores enim voluptas quaerat. Perferendis inventore laborum quisquam et sed ut nihil. Facere est corrupti quasi dolorem ratione ratione voluptas.\n\nEt minus enim voluptatem fugiat corporis possimus fuga. Maxime eum quo nulla et. Qui similique sapiente voluptas maiores ullam. Voluptatibus similique distinctio sequi alias consequatur est est. Impedit voluptatem consequatur velit et et a.\n\nNostrum alias iusto voluptatem recusandae natus est dicta. Fugiat aliquid et id consequuntur quos vitae doloremque. Sit in autem consequatur est harum est aspernatur. Esse aut eaque et tempora distinctio omnis et. Ut qui aliquid deleniti praesentium.\n\nOccaecati alias expedita nihil explicabo vel voluptatum rerum. Corrupti deserunt quas id qui eaque. Eum autem ullam velit eveniet necessitatibus modi.\n\nUt ut laudantium voluptas et et ad. Illum incidunt rerum consequatur voluptatem consequatur sapiente et sit. Sunt facere corporis aliquam et cupiditate rerum.\n\nSimilique qui molestias magni quae. Quaerat ut doloremque qui dolores rerum unde voluptatem assumenda. Ut quidem consequatur iure dolorum.\n\nIllo nisi eum eos et maiores ut accusamus. Perferendis perspiciatis aut facere ut ipsa et. Et nihil eveniet quasi quia rerum quisquam voluptas. Rerum totam beatae omnis sint aut in provident facilis.\n\nQuos ut quaerat necessitatibus consequatur veritatis et facere sit. Exercitationem et et optio iste.\n\nCum nam autem odio ipsa corrupti sit corrupti. Nihil impedit asperiores ea omnis pariatur rerum. Iure perspiciatis cupiditate est sit. Est hic asperiores dolorum inventore placeat. Rerum sit nihil voluptatem incidunt aut.\n\nQuasi vitae sed id. Ipsum consequuntur delectus iusto. Aut molestiae voluptatem ea accusamus laborum.','cancellation',1,'2025-01-08 01:09:29','2025-01-08 01:09:29');
/*!40000 ALTER TABLE `policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('1YclQOzWE4BtY2dvTs7zcxNe7OKx0Y7W0oC2qKS2',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiUk0yc3FwY0FlRE9lZ2xoaGFMblRsRUcwY2FLc0xRUGt4YUg3U2dmWiI7czoxODoiZmxhc2hlcjo6ZW52ZWxvcGVzIjthOjA6e31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozNDoiaHR0cDovL2xvY2FsaG9zdDo4MDAwL2FkbWluL2JhY2t1cCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1736399371),('NAkV2JufK9u1ycyHYJnjEoySFyIoOg4zZSl3Rw2C',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoibTE5eHk0dmtUZWhBNnEwbFB0bVJ2SkxLblVHblVITXo3ZmpFYXVzMyI7czoxODoiZmxhc2hlcjo6ZW52ZWxvcGVzIjthOjA6e31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo0MDoiaHR0cDovL2xvY2FsaG9zdDo4MDAwL2FkbWluL25vdGlmaWNhdGlvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1736329975);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL DEFAULT '{}',
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `settings_user_id_foreign` (`user_id`),
  CONSTRAINT `settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_histories`
--

DROP TABLE IF EXISTS `subscription_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `payment_ref` varchar(255) DEFAULT NULL,
  `payment_method` enum('stripe','razorpay') DEFAULT NULL,
  `status` enum('pending','paid','cancelled','failed','refunded') NOT NULL DEFAULT 'pending',
  `subscribed_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `subscription_plan_id` bigint(20) unsigned NOT NULL,
  `subscriber_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscription_histories_subscription_plan_id_foreign` (`subscription_plan_id`),
  KEY `subscription_histories_subscriber_id_foreign` (`subscriber_id`),
  CONSTRAINT `subscription_histories_subscriber_id_foreign` FOREIGN KEY (`subscriber_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscription_histories_subscription_plan_id_foreign` FOREIGN KEY (`subscription_plan_id`) REFERENCES `subscription_plans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_histories`
--

LOCK TABLES `subscription_histories` WRITE;
/*!40000 ALTER TABLE `subscription_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plans`
--

DROP TABLE IF EXISTS `subscription_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_plans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `plan_name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `features` text NOT NULL DEFAULT '{}',
  `days` int(11) NOT NULL DEFAULT 30,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plans`
--

LOCK TABLES `subscription_plans` WRITE;
/*!40000 ALTER TABLE `subscription_plans` DISABLE KEYS */;
INSERT INTO `subscription_plans` VALUES (1,'logo-free.png','Free',0,'{}',30,1,'2025-01-08 01:09:29','2025-01-08 01:09:29'),(2,'logo-basic.png','Basic',299,'{}',30,1,'2025-01-08 01:09:29','2025-01-08 01:09:29'),(3,'logo-premium.png','Premium',499,'{}',30,1,'2025-01-08 01:09:29','2025-01-08 01:09:29');
/*!40000 ALTER TABLE `subscription_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `avatar` varchar(50) DEFAULT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `is_subscribed` tinyint(1) NOT NULL DEFAULT 0,
  `subscription_plan_id` bigint(20) unsigned DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `fcm_token` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,'Manger','A','quee@quee.in',NULL,NULL,NULL,'$2y$12$lom5ctH2NTTLf60KwEb4eeWmfov3bt3z1sufE5HKBDPkczVMD9ZVO',0,NULL,1,NULL,NULL,'2025-01-08 01:09:29','2025-01-08 01:09:29'),(2,NULL,'User','A','usera@keyndex.in',NULL,'1234567890',NULL,'$2y$12$Nfl1Pd0RLt94yZ5ZtWipY.Yd7Png3Dg6rxoZbBkc0btopA/aB6vom',0,NULL,1,NULL,NULL,'2025-01-08 01:09:29','2025-01-08 01:09:29'),(3,NULL,'User','B','userb@keyndex.in',NULL,'1234567890',NULL,'$2y$12$t34ChwJ1rQTQpLrut9/KtOSv7bl1w2kgrjV6TSodX2Fk5KfbYurzi',0,NULL,1,NULL,NULL,'2025-01-08 01:09:29','2025-01-08 01:09:29'),(4,NULL,'User','C','userc@keyndex.in',NULL,'1234567890',NULL,'$2y$12$FxKI3Xy3PBoFHadp.AwIhOk8ecPK9a4M.GQsw.ZzPzAnw/SLkP7Gy',0,NULL,1,NULL,NULL,'2025-01-08 01:09:29','2025-01-08 01:09:29');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_codes`
--

DROP TABLE IF EXISTS `verification_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verification_codes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(8) NOT NULL,
  `type` enum('email','phone','both','other') NOT NULL DEFAULT 'email',
  `is_used` tinyint(1) NOT NULL DEFAULT 0,
  `expires_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `verification_codes_code_unique` (`code`),
  KEY `verification_codes_user_id_foreign` (`user_id`),
  CONSTRAINT `verification_codes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_codes`
--

LOCK TABLES `verification_codes` WRITE;
/*!40000 ALTER TABLE `verification_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification_codes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-09 10:39:36
